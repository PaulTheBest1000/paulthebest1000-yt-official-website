document.addEventListener('DOMContentLoaded', function () {
  chrome.runtime.sendMessage({ action: "popupReady" });
  const alarmAudio = document.getElementById('alarmAudio');

// Define a single audio object to reuse
alarmAudio.loop = true; // optional: keep playing

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'playAlarmSound' && msg.alarmSound) {
    // Set source and play
    alarmAudio.src = msg.alarmSound;
    alarmAudio.play().catch(err => console.error("Could not play alarm:", err));

    // ✅ reply back to background
    sendResponse({ status: 'playing' });
  }
  return true; // keeps the channel open for async responses
});

  // Function to dismiss the alarm
  function dismissAlarm() {
    alarmAudio.pause();  // Stop the alarm sound
    alarmAudio.currentTime = 0;  // Reset the audio to the beginning
    window.close();  // Close the window immediately
  }

  function snoozeAlarm() {
    alarmAudio.pause();  // Stop the alarm sound

    // Tell the background script to create a snooze alarm for 5 minutes
    chrome.runtime.sendMessage({ action: 'snoozeAlarm', minutes: 5 }, (response) => {
      console.log(response?.status || "Snooze set");
    });

    // Hide the alarm UI and close the tab
    document.querySelector('.alarm-box').style.display = 'none';  
    window.close();  // Close this tab/window
  }

  // Attach event listeners to the buttons
  const dismissButton = document.querySelector('.buttons button:first-child');
  const snoozeButton = document.querySelector('.buttons button:last-child');

  if (dismissButton && snoozeButton) {
    dismissButton.addEventListener('click', dismissAlarm);
    snoozeButton.addEventListener('click', snoozeAlarm);
  } else {
    console.error("Buttons not found in the alarm popup.");
  }
});