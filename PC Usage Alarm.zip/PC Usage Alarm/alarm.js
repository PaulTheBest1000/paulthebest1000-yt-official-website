document.addEventListener('DOMContentLoaded', function () {
  chrome.runtime.sendMessage({ action: "popupReady" });
  const alarmAudio = document.getElementById('alarmAudio');

  // Listen for messages from the background script to play the alarm sound
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'playAlarmSound') {
      alarmAudio.src = message.alarmSound;  // Set the alarm sound source
      alarmAudio.play();  // Play the alarm sound
    }
  });

  // Function to dismiss the alarm
  function dismissAlarm() {
    alarmAudio.pause();  // Stop the alarm sound
    alarmAudio.currentTime = 0;  // Reset the audio to the beginning
    window.close();  // Close the window immediately
  }

  // Function to snooze the alarm for 5 minutes
  function snoozeAlarm() {
    alarmAudio.pause();  // Stop the alarm sound
    setTimeout(() => {
      alarmAudio.play();  // Restart the alarm sound after 5 minutes

      // Open the alarm in a new tab and then close the current window
      const alarmWindow = window.open(window.location.href, '_blank');  
      if (alarmWindow) {
        // Add a slight delay before closing the current window to ensure the new one opens
        setTimeout(() => {
          window.close();  // Close the current window after opening the new one
        }, 500); // 500ms delay to allow the window to open
      } else {
        console.error("Failed to open snooze window.");
      }
    }, 5 * 60 * 1000);  // 5 minutes in milliseconds

    document.querySelector('.alarm-box').style.display = 'none';  // Hide the alarm box
  }

  // Attach event listeners to the buttons
  const dismissButton = document.querySelector('.buttons button:first-child');
  const snoozeButton = document.querySelector('.buttons button:last-child');

  if (dismissButton && snoozeButton) {
    dismissButton.addEventListener('click', dismissAlarm);
    snoozeButton.addEventListener('click', snoozeAlarm);
  } else {
    console.error("Buttons not found in the alarm popup.");
  }
});
