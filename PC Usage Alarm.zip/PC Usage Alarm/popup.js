document.addEventListener("DOMContentLoaded", () => {
  const timeLimitInput = document.getElementById('timeLimit');
  const timeUnitSelect = document.getElementById('timeUnit');
  const alarmFileInput = document.getElementById('alarmFile');
  const setAlarmBtn = document.getElementById('setAlarm');
  
  const displayTime = document.createElement('p');
  document.body.appendChild(displayTime);

  let countdownInterval = null; // store active countdown

  // 🔹 Update display with singular/plural
  function updateDisplay() {
    const value = parseInt(timeLimitInput.value) || 0;
    const unit = timeUnitSelect.value;

    let unitText = unit;
    if (value === 1) {
      if (unit === "seconds") unitText = "Second";
      if (unit === "minutes") unitText = "Minute";
      if (unit === "hours") unitText = "Hour";
    } else {
      if (unit === "seconds") unitText = "Seconds";
      if (unit === "minutes") unitText = "Minutes";
      if (unit === "hours") unitText = "Hours";
    }

    displayTime.textContent = `${value} ${unitText}`;
  }

  timeLimitInput.addEventListener("input", updateDisplay);
  timeUnitSelect.addEventListener("change", updateDisplay);
  updateDisplay();

  // 🔹 Main click handler
  setAlarmBtn.addEventListener('click', () => {
    const timeLimit = parseFloat(timeLimitInput.value);
    const timeUnit = timeUnitSelect.value;
    const alarmFile = alarmFileInput.files[0];

    // ✅ Validate input
    if (isNaN(timeLimit) || timeLimit <= 0 || !alarmFile) {
      const chordSound = new Audio('chord.mp3');
      chordSound.play().catch(err => console.error("Could not play sound:", err));
      setTimeout(() => {
        alert('Please provide a time limit and an alarm sound.');
      }, 10);
      return;
    }

    // 🔹 Convert to minutes for Chrome alarm
    let timeLimitInMinutes;
    if (timeUnit === 'seconds') timeLimitInMinutes = timeLimit / 60;
    else if (timeUnit === 'minutes') timeLimitInMinutes = timeLimit;
    else if (timeUnit === 'hours') timeLimitInMinutes = timeLimit * 60;
    else {
      console.error("Invalid time unit provided.");
      return;
    }

    if (timeLimitInMinutes < 1 / 60) timeLimitInMinutes = 1 / 60;

    const MIN_ALARM_MINUTES = 0.5 / 60; // 30 seconds minimum

    if (timeLimit < MIN_ALARM_MINUTES) {
      // Use setTimeout for short timers
      setTimeout(() => {
        chrome.windows.create({
          url: 'alarm.html',
          type: 'popup',
          width: 400,
          height: 300
        }, (win) => {
          if (chrome.runtime.lastError) return;
    
          setTimeout(() => {
            chrome.runtime.sendMessage({
              action: 'playAlarmSound',
              alarmSound: currentAlarmSound
            });
          }, 500);
        });
      }, timeLimit * 60000); // convert minutes → ms
    } else {
      // Normal long timer
      chrome.alarms.create('usage_alarm', { delayInMinutes: timeLimit });
    }    

    // 🔹 Send alarm sound to background
    const reader = new FileReader();
    reader.onload = function(event) {
      chrome.runtime.sendMessage({
        action: 'setAlarm',
        timeLimit: timeLimitInMinutes,
        alarmSound: event.target.result
      }, (response) => {
        if (response && response.status) {
          alert(response.status);
        } else {
          const errorSound = new Audio('critical-stop.mp3');
          errorSound.play().catch(err => console.error("Could not play sound:", err));
          setTimeout(() => {
            alert('Error: Alarm could not be set.');
          }, 10);
        }
      });
    };
    reader.readAsDataURL(alarmFile);

    // 🔹 Start countdown display
    if (countdownInterval) clearInterval(countdownInterval);

    let totalSeconds = timeUnit === 'seconds' ? timeLimit
      : timeUnit === 'minutes' ? timeLimit * 60
      : timeLimit * 3600;

    let remaining = totalSeconds;

    countdownInterval = setInterval(() => {
      if (remaining <= 0) {
        clearInterval(countdownInterval);
        displayTime.textContent = "Time's up!";
        return;
      }

      const hours = Math.floor(remaining / 3600);
      const minutes = Math.floor((remaining % 3600) / 60);
      const seconds = Math.floor(remaining % 60);

      const parts = [];
      if (hours > 0) parts.push(`${hours}h`);
      if (minutes > 0) parts.push(`${minutes}m`);
      parts.push(`${seconds}s`);

      displayTime.textContent = `Time left: ${parts.join(" ")}`;
      remaining--;
    }, 1000);
  });
});
