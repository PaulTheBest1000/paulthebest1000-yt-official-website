document.getElementById('setAlarm').addEventListener('click', () => {
  let timeLimit = document.getElementById('timeLimit').value;
  let timeUnit = document.getElementById('timeUnit').value;
  let alarmFile = document.getElementById('alarmFile').files[0];

  if (timeLimit && alarmFile) {
    let timeLimitInMinutes;

    if (timeUnit === 'seconds') {
        timeLimitInMinutes = timeLimit / 60; // Convert seconds to minutes
    } else if (timeUnit === 'minutes') {
        timeLimitInMinutes = timeLimit; // Already in minutes
    } else if (timeUnit === 'hours') {
        timeLimitInMinutes = timeLimit * 60; // Convert hours to minutes
    } else {
        console.error("Invalid time unit provided.");
        timeLimitInMinutes = 0;
    }

    // Ensure timeLimitInMinutes is a number
    timeLimitInMinutes = Number(timeLimitInMinutes);

    // Check if it's a valid number
    if (isNaN(timeLimitInMinutes)) {
        console.error("Invalid timeLimitInMinutes: Not a number");
        return;
    }

    // Now use timeLimitInMinutes in alarms.create
    chrome.alarms.create('myAlarm', {
        delayInMinutes: timeLimitInMinutes, // Should be a number now
    });

    console.log("Time limit in minutes:", timeLimitInMinutes);

      let reader = new FileReader();
      reader.onload = function(event) {
          // Send settings to background.js
          chrome.runtime.sendMessage(
              {
                  action: 'setAlarm',
                  timeLimit: timeLimitInMinutes,
                  alarmSound: event.target.result, // Send the alarm sound data URL
              },
              (response) => {
                  // Ensure the response has the 'status' property
                  if (response && response.status) {
                      alert(response.status);  // Show success message
                  } else {
                      alert('Error: Alarm could not be set.');
                  }
              }
          );
      };

      reader.readAsDataURL(alarmFile); // Convert the file to a data URL
  } else {
      alert('Please provide a time limit and an alarm sound.');
  }
});

// Connect to the background script via a persistent port
const port = chrome.runtime.connect({ name: "popup" });

port.onMessage.addListener((message) => {
  if (message.action === 'playAlarmSound') {
      const audio = new Audio(message.alarmSound);
      audio.play();
  }
});
