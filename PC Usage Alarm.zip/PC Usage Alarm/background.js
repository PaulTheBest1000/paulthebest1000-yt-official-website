// background.js
chrome.runtime.onInstalled.addListener(() => {});

let currentAlarmSound = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'setAlarm') {
    const { timeLimit, alarmSound } = message;
    if (!alarmSound || !timeLimit) {
      sendResponse({ status: 'Error: Please provide both time limit and alarm sound.' });
      return true;
    }

    // Store alarm sound in memory
    currentAlarmSound = alarmSound;

    chrome.alarms.create('usage_alarm', { delayInMinutes: timeLimit });
    sendResponse({ status: 'Alarm set successfully!' });

    // ✅ Do NOT play Audio here; it will fail in background
    // Play chime in popup instead
    return true;
  }

  if (message.action === 'snoozeAlarm') {
    const minutes = message.minutes || 5;
    chrome.alarms.create('usage_alarm', { delayInMinutes: minutes });
    sendResponse({ status: `Snoozed for ${minutes} minutes` });
    return true;
  }
});

// When an alarm fires
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'usage_alarm' && currentAlarmSound) {
    chrome.windows.create({
      url: 'alarm.html',
      type: 'popup',
      width: 400,
      height: 300
    }, (win) => {
      if (chrome.runtime.lastError) return;

      // Wait for the popup to load, then send the sound
      setTimeout(() => {
        chrome.runtime.sendMessage({
          action: 'playAlarmSound',
          alarmSound: currentAlarmSound
        });
      }, 500); // 0.5s delay ensures popup is ready
    });
  }
});
