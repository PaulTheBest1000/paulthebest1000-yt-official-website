// When the extension is installed
chrome.runtime.onInstalled.addListener(() => {});

// When an alarm fires
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'usage_alarm') {
    // Retrieve the alarm sound from local storage
    chrome.storage.local.get('alarmSound', (result) => {
      if (result.alarmSound) {
        // Open the alarm popup window
        chrome.windows.create({
          url: 'alarm.html',
          type: 'popup',
          width: 400,
          height: 300
        }, (window) => {
          if (chrome.runtime.lastError) return;

          // Send the alarm sound to the newly created popup window
          setTimeout(() => {
            chrome.tabs.query({ windowId: window.id }, (tabs) => {
              if (chrome.runtime.lastError || !tabs || tabs.length === 0) return;

              chrome.tabs.sendMessage(tabs[0].id, {
                action: 'playAlarmSound',
                alarmSound: result.alarmSound
              });
            });
          }, 500); // Wait 500ms to ensure popup loads
        });
      }
    });
  }
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'setAlarm') {
    const { timeLimit, alarmSound, warnInterval } = message;

    if (!alarmSound || !timeLimit) {
      sendResponse({ status: 'Error: Please provide both time limit and alarm sound.' });
      return;
    }

    chrome.storage.local.set({ alarmSound, warnInterval }, () => {
      chrome.alarms.create('usage_alarm', { delayInMinutes: timeLimit });
      sendResponse({ status: 'Alarm set successfully!' });
    });

    return true;
  }

  if (message.action === 'snoozeAlarm') {
    const minutes = message.minutes || 5;
    chrome.alarms.create('usage_alarm', { delayInMinutes: minutes });
    sendResponse({ status: `Snoozed for ${minutes} minutes` });
    return true;
  }
});
